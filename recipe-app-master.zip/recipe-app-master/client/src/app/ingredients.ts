export class Ingredients {
    id: number;
    name: string;
  }
  